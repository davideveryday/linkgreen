<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>EcoLink</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="imagem/png" href="imagem/LOGO-EL.png">

</head>

<body>
    <header>
        <div class="navegar">
            <h1>EcoLink</h1>
            <nav>
                <ul>
                    <li><a href="index.php" class="active">Home</a></li>
                    <li><a href="cadastro.php">Cadastro</a></li>
                    <li><a href="vagas.php">Vagas</a></li>
                    <li><a href="doacao.php">Doação</a></li>
                    <li><a href="contato.php">Contato</a></li>
                    <li><a href="Grupo.php">Participantes</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section class="card">
            <h2>Bem-vindo ao EcoLink</h2>
            <p>A plataforma que conecta talentos com empresas sustentáveis.</p>
            <p>Construindo um mercado de trabalho mais consciente, inclusivo e sustentável.</p>
            <a href="cadastro.php" class="btn">Comece Agora</a>
            <a href="vagas.php" class="btn">Ver Vagas</a>
        </section>

        <section class="card">
            <h3>Nossa Missão</h3>
            <p>Desenvolver uma plataforma digital que conecta pessoas em busca de oportunidades profissionais com
                empresas e iniciativas que promovem sustentabilidade e responsabilidade social.</p>
        </section>

        <section class="card">
            <h3>Como Funciona</h3>
            <ol>
                <li><strong>Cadastre-se:</strong> Profissionais e empresas podem se cadastrar gratuitamente.</li>
                <li><strong>Explore Vagas:</strong> Empresas postam vagas focadas em sustentabilidade.</li>
                <li><strong>Apoie Causas:</strong> Doe para empresas sustentáveis e apoie suas causas.</li>
            </ol>
        </section>

        <section class="card">
            <h3>Nosso Impacto</h3>
            <ul>
                <li><strong>Sustentabilidade:</strong> Práticas ecológicas e inovação verde.</li>
                <li><strong>Impacto Social:</strong> Conectando talentos com propósito.</li>
                <li><strong>Crescimento:</strong> Desenvolvendo carreiras com significado.</li>
            </ul>
        </section>
    </main>

    <footer>
        <p>© 2025 EcoLink - EcoVocação. Todos os direitos reservados do nome registrado "GrupoGostosinho©".</p>
        <p>Desenvolvido para promover sustentabilidade e impacto social positivo 🌱</p>
    </footer>
</body>

</html>