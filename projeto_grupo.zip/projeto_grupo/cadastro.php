<?php include('conexao.php'); ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro - EcoVocação</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>🌿 EcoVocação</h1>
    <nav>
      <ul>
        <li><a href="index.html">Início</a></li>
        <li><a href="cadastro.php">Cadastro</a></li>
      </ul>
    </nav>
  </header>

  <section class="conteudo">
    <h2>Cadastro de Usuário</h2>

    <form method="POST" action="">
      <label>Nome Completo:</label><br>
      <input type="text" name="nome" required><br><br>

      <label>Email:</label><br>
      <input type="email" name="email" required><br><br>

      <label>Senha:</label><br>
      <input type="password" name="senha" required><br><br>

      <label>Tipo de Usuário:</label><br>
      <select name="tipo" required>
        <option value="profissional">Profissional</option>
        <option value="empresa">Empresa</option>
      </select><br><br>

      <input type="submit" name="cadastrar" value="Cadastrar" class="botao">
    </form>

    <?php
    if (isset($_POST['cadastrar'])) {
      $nome = $_POST['nome'];
      $email = $_POST['email'];
      $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
      $tipo = $_POST['tipo'];

      $sql = "INSERT INTO usuarios (nome, email, senha, tipo)
              VALUES ('$nome', '$email', '$senha', '$tipo')";

      if ($conexao->query($sql) === TRUE) {
        echo "<p style='color:green;'>Usuário cadastrado com sucesso!</p>";
      } else {
        echo "<p style='color:red;'>Erro ao cadastrar: " . $conexao->error . "</p>";
      }
    }
    ?>
  </section>

  <footer>
    <p>© 2025 EcoVocação | Desenvolvido por Guilherme e equipe - UNICID</p>
  </footer>
</body>
</html>
