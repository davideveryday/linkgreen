<?php
$conn = new mysqli("localhost","root","","recrutaverde");
if($conn->connect_error) { die("Erro: ".$conn->connect_error); }

$result = $conn->query("SELECT * FROM vagas");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Vagas - RecrutaVerde</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="container">
        <h1>RecrutaVerde</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="cadastro.php">Cadastro</a></li>
                <li><a href="vagas.php">Vagas</a></li>
                <li><a href="doacao.php">Doação</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="container">
    <h2>Vagas Sustentáveis</h2>
    <?php
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<h3>".$row['titulo']."</h3>";
            echo "<p><strong>Empresa:</strong> ".$row['empresa']."</p>";
            echo "<p><strong>Área:</strong> ".$row['area']."</p>";
            echo "<p>".$row['descricao']."</p>";
            echo "</div>";
        }
    } else {
        echo "<p class='card'>Nenhuma vaga disponível no momento.</p>";
    }
    ?>
</main>

<footer>
    <p>© 2025 RecrutaVerde - EcoVocação. Todos os direitos reservados.</p>
</footer>
</body>
</html>
