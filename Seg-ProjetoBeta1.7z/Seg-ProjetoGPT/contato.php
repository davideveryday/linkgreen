<?php
$conn = new mysqli("localhost","root","","recrutaverde");
if($conn->connect_error) { die("Erro: ".$conn->connect_error); }

$msg = "";
if(isset($_POST['enviar'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $stmt = $conn->prepare("INSERT INTO contatos (nome,email,assunto,mensagem) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss",$nome,$email,$assunto,$mensagem);
    if($stmt->execute()){
        $msg = "Mensagem enviada com sucesso!";
    } else {
        $msg = "Erro ao enviar: ".$stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Contato - RecrutaVerde</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="container">
        <h1>RecrutaVerde</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="cadastro.php">Cadastro</a></li>
                <li><a href="vagas.php">Vagas</a></li>
                <li><a href="doacao.php">Doação</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="container">
    <h2>Entre em Contato</h2>
    <?php if($msg) echo "<p class='card'>$msg</p>"; ?>
    <form method="POST">
        <label>Nome Completo</label>
        <input type="text" name="nome" required>

        <label>E-mail</label>
        <input type="email" name="email" required>

        <label>Assunto</label>
        <input type="text" name="assunto" required>

        <label>Mensagem</label>
        <textarea name="mensagem" required></textarea>

        <button type="submit" name="enviar" class="btn">Enviar Mensagem</button>
    </form>
</main>

<footer>
    <p>© 2025 RecrutaVerde - EcoVocação. Todos os direitos reservados.</p>
</footer>
</body>
</html>
