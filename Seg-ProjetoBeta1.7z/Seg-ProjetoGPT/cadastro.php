<?php
// Conexão com banco de dados
$conn = new mysqli("localhost","root","","recrutaverde");
if($conn->connect_error) {
    die("Conexão falhou: ".$conn->connect_error);
}

// Processar formulário
$msg = "";
if(isset($_POST['cadastrar'])) {
    $tipo = $_POST['tipo'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $telefone = $_POST['telefone'];
    $area = $_POST['area'] ?? '';
    $descricao = $_POST['descricao'] ?? '';
    $localizacao = $_POST['localizacao'] ?? '';
    $site = $_POST['site'] ?? '';

    $stmt = $conn->prepare("INSERT INTO usuarios (tipo,nome,email,senha,telefone,area,descricao,localizacao,site) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssssss",$tipo,$nome,$email,$senha,$telefone,$area,$descricao,$localizacao,$site);

    if($stmt->execute()){
        $msg = "Cadastro realizado com sucesso!";
    } else {
        $msg = "Erro ao cadastrar: ".$stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Cadastro - RecrutaVerde</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="container">
        <h1>RecrutaVerde</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="cadastro.php">Cadastro</a></li>
                <li><a href="vagas.php">Vagas</a></li>
                <li><a href="doacao.php">Doação</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="container">
    <h2>Junte-se à nossa comunidade sustentável</h2>
    <?php if($msg) echo "<p class='card'>$msg</p>"; ?>

    <form method="POST">
        <label>Tipo de Cadastro</label>
        <select name="tipo" required>
            <option value="">Selecione</option>
            <option value="profissional">Profissional</option>
            <option value="empresa">Empresa</option>
        </select>

        <label>Nome</label>
        <input type="text" name="nome" required>

        <label>E-mail</label>
        <input type="email" name="email" required>

        <label>Senha</label>
        <input type="password" name="senha" required>

        <label>Telefone</label>
        <input type="text" name="telefone">

        <label>Área / Sustentabilidade</label>
        <input type="text" name="area">

        <label>Descrição (apenas empresas)</label>
        <textarea name="descricao"></textarea>

        <label>Localização (apenas empresas)</label>
        <input type="text" name="localizacao">

        <label>Site (apenas empresas)</label>
        <input type="text" name="site">

        <button type="submit" name="cadastrar" class="btn">Cadastrar</button>
    </form>
</main>

<footer>
    <p>© 2025 RecrutaVerde - EcoVocação. Todos os direitos reservados.</p>
</footer>
</body>
</html>
