<?php
// Importa o arquivo de configuração do banco
include('config/config.php');

$msg = "";
if(isset($_POST['enviar'])){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $stmt = $conn->prepare("INSERT INTO contatos (nome,email,assunto,mensagem) VALUES (?,?,?,?)");
    if(!$stmt){
        die("Erro na preparação da query: " . $conn->error);
    }

    $stmt->bind_param("ssss",$nome,$email,$assunto,$mensagem);
    if($stmt->execute()){
        $msg = "Sua mensagem foi recebida com sucesso! Nossa equipe entrará em contato em breve.";
    } else {
        $msg = "Erro ao enviar sua mensagem: ".$stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Contato - EcoLink</title>
<link rel="stylesheet" href="style.css">
<style>
/* Estilos adicionais só para essa página (pode mover pro style.css depois) */
.container {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background: #f5f5f5;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}
.container h2 {
    text-align: center;
    color: #2e7d32;
}
.container p.intro {
    text-align: center;
    margin-bottom: 25px;
    color: #444;
    font-size: 16px;
}
.card {
    background-color: #e8f5e9;
    border: 1px solid #2e7d32;
    color: #2e7d32;
    padding: 10px;
    text-align: center;
    border-radius: 6px;
    margin-bottom: 15px;
    font-weight: bold;
}
.btn {
    background-color: #2e7d32;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
}
.btn:hover {
    background-color: #1b5e20;
}
</style>
</head>
<body>
<header>
    <div class="navegar">
        <h1>EcoLink</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="cadastro.php">Cadastro</a></li>
                <li><a href="vagas.php">Vagas</a></li>
                <li><a href="doacao.php">Doação</a></li>
                <li><a href="contato.php" class="active">Contato</a></li>
                <li><a href="Grupo.php">Participantes</a></li>
            </ul>
        </nav>
    </div>
</header>

<main class="container">
    <h2>Entre em Contato</h2>

    <!-- Mensagem de explicação para o visitante -->
    <p class="intro">
        Este espaço é destinado para você entrar em contato diretamente com a equipe do <strong>EcoLink</strong>!  
        Envie suas dúvidas, sugestões, parcerias ou qualquer mensagem — responderemos o mais breve possível 🌱.
    </p>

    <!-- Mensagem de retorno (sucesso ou erro) -->
    <?php if($msg): ?>
        <p class="card"><?php echo $msg; ?></p>
    <?php endif; ?>

    <!-- Formulário -->
    <form method="POST">
        <label>Nome Completo</label>
        <input type="text" name="nome" required>

        <label>E-mail</label>
        <input type="email" name="email" required>

        <label>Assunto</label>
        <input type="text" name="assunto" required>

        <label>Mensagem</label>
        <textarea name="mensagem" required></textarea>

        <button type="submit" name="enviar" class="btn">Enviar Mensagem</button>
    </form>
</main>

<footer>
    <p>© 2025 EcoLink - EcoVocação. Todos os direitos reservados do nome registrado "GrupoGostosinho©".</p>
    <p>Desenvolvido para promover sustentabilidade e impacto social positivo 🌱</p>
</footer>
</body>
</html>
